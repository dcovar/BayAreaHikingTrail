//
//  TrailTableViewCell.swift
//  HikingJunkie
//
//  Created by Jake Min on 3/15/16.
//  Copyright © 2016 DeAnza. All rights reserved.
//

import UIKit

class TrailTableViewCell: UITableViewCell {
    @IBOutlet var TrailImage: UIImageView!
    @IBOutlet var TrailName: UILabel!
    @IBOutlet var TrailCity: UILabel!
    @IBOutlet var TrailLength: UILabel!
    @IBOutlet var TrailTime: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
